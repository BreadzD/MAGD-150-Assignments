'Code based off of Lab_9, Example 4'
let playing = false;
let video;
let soundFile;
'Declares the varibles for the video and sound format used in the code.'
function preload() {
  Noise = loadSound('SpringLock.mp3');
}
'Loads both the sound file and video before starting the setup.'
function setup() {
Noise.setVolume(0.1);
   reverb = new p5.Reverb();
  reverb.process(Noise, 10, 5);
   Noise.play();
  video  = createVideo(['Mirrors.mp4']);
   button = createButton('Play');
  button.mousePressed(toggleVid);
}
'Adds reverb to the sound, sets the volume and plays the noise when starting up the form.'
function toggleVid() {
  if (playing) {
    fingers.pause();
    button.html('play');
    'Plays the video file.'
  } else {
    video.loop();
    button.html('pause');
    'Allows you to loop and pause the video'
  }
  playing = !playing;
  'plays the video file'
}
