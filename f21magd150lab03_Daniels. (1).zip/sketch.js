var pressed = 0;
var pressedState = 0;
var x = 0;
var y = 0;
function setup() {
  createCanvas(800, 800);
}

function draw() {

  background(255);
  if (pressedState == 1){
    fill(225, 0,0);
    stroke(circle(pmouseX, pmouseY, 100));
    
  } else {
    fill(0,0,100);
      circle(mouseX, mouseY,100 );
  }
}

function mousePressed(){
  pressed = pressed+1
  pressedState =(pressed % 2);


}



