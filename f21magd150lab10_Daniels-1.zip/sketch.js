"Earth Image from: https://pixabay.com/photos/map-earth-world-planet-environment-4818844/"
let img;
let table;
let img2;
let theta; 
function setup() {

  createCanvas(400, 400, WEBGL);
  theta = PI/8
  img = loadImage('MAP.jpg');
   'Declares the varbles for the file and loads the main image displayed at the start'
}
function preload() {
   table = loadTable('Spreadsheet.csv', 'csv', 'header');
  'Loads the table'
}
function draw() {
  let locX = mouseX - width / 2;
  let locY = mouseY - height / 2;
  print(table.getRowCount());
  background(0);
  rotateX(279 -100 );
  rotateY(226-100 );
  rotateZ( theta);
  sphere(70);
  texture(img);
    pointLight(250, 250, 250, locX, locY, 50);
   theta += PI/60;
   camera( 100, 100, 150, 10, 10, 5);
  ambientLight(100);
  img2 = loadImage('color.png')
   cone(60, -200);
    texture(img);
   cylinder(200, 50);
    texture(img);
  'Creates the different shapes and applies textures for them.'
}
function mouseReleased() {
  camera( 10, 10, 10, 0, 0, 0);
    img = loadImage('philprofile.png')
   cone(0, 10);
  'Makes the camera zoom and changes the textures on each shape'
 
}