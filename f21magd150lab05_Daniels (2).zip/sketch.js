var circleX, circleY;  // Position of circle button
var circleSize = 93;   // Diameter of circle
var y = 50;
let a; // line height
var cx,cy; //circle
var circleOver = false;
var rx, ry //rect speed
var cspeed; // motion for circle

function setup() {
  createCanvas(600, 400);
    circleX = width/2+circleSize/2+10;
  circleY = height/2;
  stroke(250);
  a = height / 2;
  cx=25;
  cy=height/2;
  cspeed =3;
  rx=0;
  ry=0;
  rxSpeed=2;
  rySpeed=2;
  b = 0;
}




function draw() {
  background(1);
  fill(250);
 circle(circleX, circleY, 40)


fill(0);
//circle moving diagonally
   
rectMode(CENTER)
  
  rect(100, 100, 50, 50);
  fill(20, 100, 200)
  
  circle(rx+25,ry+25,50);
  text('Background', 70, 100);  
  fill(0);
  text('Color', 342, 200); 
  rx+= rxSpeed;
  ry+= rySpeed;
  
  if (rx<=0 || rx+50 >= width){
    rxSpeed *= -1;
  }
  
  if (ry<=0 || ry+50 >= height){
    rySpeed *=-1;
  }
  
}
function mousePressed() {
  
}
function overRect()  {
  if (mouseX >= 100 && mouseX <= 100 +width && 
      mouseY >= 50 && mouseY <= 50 +height) {
    return true;
    fill(120, 50, 10, 21);
  } else {
    return false;
  }
}

function overCircle() {
  var disX = circleX - mouseX;
  var disY = circleY - mouseY;
  if (sqrt(sq(disX) + sq(disY)) < diameter/2 ) {
    return true;
    background(200);
  } else {
    return false;
  }
}

