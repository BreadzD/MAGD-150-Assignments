function setup() {
  createCanvas(200, 200);
   
 
}

function draw() {
 
  background(10);
stroke(0);
  strokeWeight(1);
   ellipseMode(CORNER);
   rect(100,100, 100, 100);
  rect(0,0, 100, 100);
   ellipseMode(CENTER);
  fill(255);
   rect(45,100, 30, 140);
  fill(0);
  rect(45,4, 30, 100);
 rect(145,70, 30, 140);
  
  fill(255);
  noStroke();
  ellipse(140, 10, 20, 20);
  ellipse(180, 10, 20, 20);
  ellipse(40, 110, 20, 20);
  ellipse(80, 110, 20, 20);
  rect(145,4, 30, 100);
  
  
stroke(10);
  fill(0);
  ellipse(40, 10, 20, 20);
  ellipse(80, 10, 20, 20);
  ellipse(140, 110, 20, 20);
  ellipse(180, 110, 20, 20);
  fill(255);
  stroke(255);
  line(100, 0,140,150);
  stroke(0);
  line(40, 150,0,0);
  
stroke(225);
   strokeWeight(10);
  point(140, 10);
  point(180, 10);
  stroke(35);
  point(40, 10);
  point(80, 10);
}
